# Luminai

A production-oriented, mobile-first static frontend foundation for a universal platform.

## Files

- `index.html` — semantic application shell and all public sections.
- `style.css` — responsive visual system, layout, accessibility states and restrained motion.
- `script.js` — navigation, universal search, education filters, local chat UI, loading/empty states and integration points.

## Run

Open `index.html` directly for a static preview, or serve the folder with any static web server.

## Backend integration

The frontend intentionally does not pretend to have a real AI backend or media database.

### AI

In `script.js`, replace `sendToAI()` with a call to your own server endpoint, e.g. `/api/chat`.

Do not put provider API keys in browser JavaScript.

### Education / Movies / Music

Replace the sample catalog entries with your own API/database adapters. The UI is already structured around stable section IDs and data attributes so the visual shell does not need to be rebuilt.

## Production checklist

- Connect real backend/API services.
- Add server-side authentication only where required.
- Add a secure API proxy for AI providers.
- Replace placeholder portfolio information.
- Replace sample media/resource cards with your own legal catalog data.
- Configure CSP, caching, compression and HTTPS at deployment.
- Add your preferred analytics only if needed and with appropriate privacy controls.

No copyrighted media is bundled with this project.
